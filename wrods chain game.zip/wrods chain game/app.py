from flask import Flask, render_template, request, jsonify, redirect, url_for
from game import WordChainGame
import time

app = Flask(__name__)
game = WordChainGame()

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        action = request.form.get("action", "play")
        
        if action == "reset":
            game.reset_game()
            return redirect(url_for('index'))
        
        elif action == "pause":
            is_paused = game.toggle_pause()
            timer_value = int(request.form.get("timer_value", 10))
            game.update_timer(timer_value)
            return redirect(url_for('index'))
        
        elif action == "play":
            player_word = request.form.get("player_word", "").strip().lower()
            expected_start = request.form.get("last_letter")
            start_time = float(request.form.get("start_time", 0))
            
            # Check if time limit exceeded
            if time.time() - start_time > 10:
                return render_template('time_exceeded.html',
                                    last_word=player_word,
                                    words_used=len(game.used_words))
            
            success, message, ai_word, is_duplicate = game.player_move(player_word, expected_start)
            if not success:
                if is_duplicate:
                    return render_template('duplicate_word.html',
                        last_word=player_word,
                        words_used=len(game.used_words))
                else:
                    return render_template('wrong_word.html',
                        error_message=message,
                        last_word=player_word,
                        words_used=len(game.used_words))
            
            if ai_word:
                last_letter = ai_word[-1]
            else:
                message = "🎉 You win! AI has no word!"
                last_letter = ""

    return render_template("index.html", 
                         player_word="",
                         ai_word=game.last_ai_word if hasattr(game, 'last_ai_word') else "",
                         message="",
                         last_letter=game.last_letter if hasattr(game, 'last_letter') else "",
                         game_state={
                             "game_over": game.game_over,
                             "is_paused": game.is_paused,
                             "timer_value": game.timer_value
                         })

if __name__ == "__main__":
    app.run(debug=True)
